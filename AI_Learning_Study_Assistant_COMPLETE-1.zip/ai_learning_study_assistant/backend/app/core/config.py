from pydantic_settings import BaseSettings, SettingsConfigDict
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]

class Settings(BaseSettings):
    app_name: str = "AI Learning & Study Assistant"
    database_url: str = "sqlite+aiosqlite:///../data/app.db"
    chroma_dir: str = "../data/chroma"
    upload_dir: str = "../data/uploads"
    embedding_model: str = "all-MiniLM-L6-v2"
    top_k: int = 5
    max_upload_mb: int = 20
    cors_origins: str = "http://localhost:5173"
    llm_provider: str = "openai"
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    openai_model: str = "gpt-4o-mini"
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "llama3.2:3b"
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

settings = Settings()
settings.chroma_dir = str((BASE_DIR / settings.chroma_dir).resolve())
settings.upload_dir = str((BASE_DIR / settings.upload_dir).resolve())
Path(settings.chroma_dir).mkdir(parents=True, exist_ok=True)
Path(settings.upload_dir).mkdir(parents=True, exist_ok=True)
