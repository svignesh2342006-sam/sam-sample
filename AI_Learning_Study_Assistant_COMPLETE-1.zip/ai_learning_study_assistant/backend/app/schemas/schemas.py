from pydantic import BaseModel, Field
from typing import Optional, Any

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    conversation_id: Optional[int] = None

class ChatResponse(BaseModel):
    answer: str
    conversation_id: int
    intent: str
    sources: list[dict[str, Any]] = []
    tools_used: list[str] = []
    memories_used: list[str] = []

class MemoryCreate(BaseModel):
    content: str = Field(min_length=2, max_length=4000)
    kind: str = "learning"
    importance: int = Field(default=3, ge=1, le=5)

class PlanRequest(BaseModel):
    goal: str = Field(min_length=2, max_length=4000)
    days: int = Field(default=7, ge=1, le=60)
    hours_per_day: float = Field(default=2, gt=0, le=16)

class QuizRequest(BaseModel):
    topic: str = Field(min_length=1, max_length=2000)
    count: int = Field(default=10, ge=1, le=30)

class SummaryRequest(BaseModel):
    topic: str = Field(min_length=1, max_length=4000)

class CalculationRequest(BaseModel):
    expression: str = Field(min_length=1, max_length=500)
