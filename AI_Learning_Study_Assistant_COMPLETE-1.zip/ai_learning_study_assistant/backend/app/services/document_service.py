from pathlib import Path
from pypdf import PdfReader
from docx import Document as DocxDocument
import re

def extract_text(path: Path) -> list[tuple[str, int | None]]:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        reader = PdfReader(str(path))
        return [(p.extract_text() or "", i + 1) for i, p in enumerate(reader.pages)]
    if suffix == ".docx":
        doc = DocxDocument(str(path))
        return [("\n".join(p.text for p in doc.paragraphs), None)]
    if suffix in {".txt", ".md"}:
        return [(path.read_text(encoding="utf-8", errors="ignore"), None)]
    raise ValueError("Unsupported file type. Use PDF, DOCX, TXT or MD.")

def clean_text(text: str) -> str:
    text = text.replace("\x00", " ")
    return re.sub(r"\s+", " ", text).strip()

def chunk_pages(pages, chunk_size=1100, overlap=180):
    chunks = []
    for text, page in pages:
        text = clean_text(text)
        if not text: continue
        start = 0
        while start < len(text):
            end = min(len(text), start + chunk_size)
            piece = text[start:end].strip()
            if piece:
                chunks.append((piece, page))
            if end >= len(text): break
            start = max(0, end - overlap)
    return chunks
