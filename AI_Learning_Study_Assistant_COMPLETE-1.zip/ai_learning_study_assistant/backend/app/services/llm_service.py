import httpx
from openai import AsyncOpenAI
from app.core.config import settings

SYSTEM = """You are an AI Learning & Study Assistant. Answer as an academic study coach. For course-specific questions, use ONLY the supplied course context as the factual knowledge basis. If the retrieved course context does not contain the answer, say that the uploaded course material does not provide enough information. You may use learner memory to personalize the response, but do not invent memories. Be clear, structured, concise, and useful. When tools were used, incorporate their results accurately."""

class LLMService:
    async def generate(self, user_message, context, memory, tool_results=None, mode="answer"):
        prompt = f"""Mode: {mode}\nUser request:\n{user_message}\n\nCOURSE CONTEXT:\n{context or '[No relevant course content retrieved]'}\n\nLEARNER MEMORY:\n{memory or '[No relevant memory]'}\n\nTOOL RESULTS:\n{tool_results or '[No tools used]'}\n\nProduce the final learning response."""
        if settings.llm_provider.lower() == "ollama":
            async with httpx.AsyncClient(timeout=120) as client:
                r = await client.post(f"{settings.ollama_base_url.rstrip('/')}/api/chat", json={"model": settings.ollama_model, "messages": [{"role":"system","content":SYSTEM},{"role":"user","content":prompt}], "stream": False})
                r.raise_for_status(); return r.json()["message"]["content"]
        if not settings.openai_api_key:
            raise RuntimeError("OPENAI_API_KEY is not configured. Set LLM_PROVIDER=ollama for a local Ollama model, or configure an OpenAI-compatible API key.")
        client = AsyncOpenAI(api_key=settings.openai_api_key, base_url=settings.openai_base_url)
        r = await client.chat.completions.create(model=settings.openai_model, messages=[{"role":"system","content":SYSTEM},{"role":"user","content":prompt}], temperature=0.2)
        return r.choices[0].message.content or "No response generated."

llm_service = LLMService()
