import chromadb
from sentence_transformers import SentenceTransformer
from app.core.config import settings

class VectorService:
    def __init__(self):
        self.client = chromadb.PersistentClient(path=settings.chroma_dir)
        self.collection = self.client.get_or_create_collection("course_material")
        self.model = SentenceTransformer(settings.embedding_model)

    def add(self, ids, texts, metadatas):
        embeddings = self.model.encode(texts, normalize_embeddings=True).tolist()
        self.collection.upsert(ids=ids, documents=texts, metadatas=metadatas, embeddings=embeddings)

    def delete_document(self, document_id):
        self.collection.delete(where={"document_id": str(document_id)})

    def search(self, query, top_k=None):
        q = self.model.encode([query], normalize_embeddings=True).tolist()
        result = self.collection.query(query_embeddings=q, n_results=top_k or settings.top_k, include=["documents", "metadatas", "distances"])
        out = []
        docs = result.get("documents", [[]])[0]
        metas = result.get("metadatas", [[]])[0]
        dists = result.get("distances", [[]])[0]
        for doc, meta, dist in zip(docs, metas, dists):
            out.append({"content": doc, "metadata": meta or {}, "distance": float(dist)})
        return out

vector_service = VectorService()
