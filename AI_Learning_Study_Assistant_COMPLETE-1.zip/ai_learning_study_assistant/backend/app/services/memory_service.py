from datetime import datetime, timezone
from sqlalchemy import select
from app.models.models import Memory

class MemoryService:
    async def add(self, db, content, kind="learning", importance=3):
        m = Memory(content=content.strip(), kind=kind, importance=importance)
        db.add(m); await db.commit(); await db.refresh(m); return m

    async def retrieve(self, db, query, limit=5):
        result = await db.execute(select(Memory).order_by(Memory.importance.desc(), Memory.created_at.desc()).limit(100))
        memories = result.scalars().all()
        terms = {x.lower() for x in query.split() if len(x) > 2}
        scored = []
        for m in memories:
            overlap = sum(1 for t in terms if t in m.content.lower())
            score = overlap * 3 + m.importance
            if overlap or not terms:
                scored.append((score, m))
        scored.sort(key=lambda x: x[0], reverse=True)
        chosen = [m for _, m in scored[:limit]]
        now = datetime.now(timezone.utc)
        for m in chosen: m.last_used_at = now
        if chosen: await db.commit()
        return chosen

memory_service = MemoryService()
