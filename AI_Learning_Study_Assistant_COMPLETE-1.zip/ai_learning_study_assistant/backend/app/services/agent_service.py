import re
from app.services.llm_service import llm_service
from app.services.vector_service import vector_service
from app.services.memory_service import memory_service
from app.tools.tools import calculator, current_datetime, build_schedule

class AgentService:
    def intent(self, q):
        s=q.lower()
        if any(x in s for x in ["study plan", "learning plan", "revision plan", "7-day", "7 day"]): return "plan"
        if any(x in s for x in ["quiz", "mcq", "practice questions"]): return "quiz"
        if any(x in s for x in ["summarize", "summary", "revision notes", "notes"]): return "summary"
        if any(x in s for x in ["calculate", "compute", "what is ", "+", "*", "/"]): return "tool"
        if "what did i study" in s or "previously" in s: return "memory"
        return "qa"

    async def run(self, db, message):
        intent = self.intent(message)
        memories = await memory_service.retrieve(db, message)
        memories_text = "\n".join(f"- {m.content}" for m in memories)
        retrieved = vector_service.search(message)
        context = "\n\n".join(f"[Source: {x['metadata'].get('filename','course material')}, page {x['metadata'].get('page','N/A')}]\n{x['content']}" for x in retrieved)
        tools=[]; tool_results=[]
        if intent == "tool":
            match = re.search(r"(?:calculate|compute)\s+(.+)", message, re.I)
            expr = match.group(1).strip() if match else None
            if expr and re.fullmatch(r"[0-9+\-*/().%\s]+", expr):
                try: tool_results.append("Calculator result: " + calculator(expr)); tools.append("calculator")
                except Exception: pass
            if "time" in message.lower() or "date" in message.lower():
                tool_results.append("Current local date/time: " + current_datetime()); tools.append("datetime")
        if intent == "plan":
            m = re.search(r"(\d+)\s*(?:day|days)", message.lower()); days=int(m.group(1)) if m else 7
            h = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*hours?", message.lower()); hours=float(h.group(1)) if h else 2
            schedule=build_schedule(message, days, hours); tool_results.append("Schedule tool result:\n"+"\n".join(f"Day {x['day']}: {x['focus']} ({x['hours']}h)" for x in schedule)); tools.append("study_schedule")
        answer=await llm_service.generate(message, context, memories_text, "\n".join(tool_results), intent)
        memory_candidate = f"User requested: {message[:500]}\nAssistant responded: {answer[:800]}"
        await memory_service.add(db, memory_candidate, "conversation", 2)
        sources=[{"filename":x["metadata"].get("filename"),"page":x["metadata"].get("page"),"content":x["content"][:300],"distance":x["distance"]} for x in retrieved]
        return answer, intent, sources, tools, [m.content for m in memories]

agent_service=AgentService()
