import ast, operator as op
from datetime import datetime, timezone

_ALLOWED = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.Pow: op.pow, ast.Mod: op.mod, ast.USub: op.neg, ast.UAdd: op.pos}

def _safe_eval(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)): return node.value
    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED: return _ALLOWED[type(node.op)](_safe_eval(node.operand))
    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED: return _ALLOWED[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    raise ValueError("Only basic arithmetic is allowed")

def calculator(expression):
    tree = ast.parse(expression, mode="eval")
    return str(_safe_eval(tree.body))

def current_datetime():
    return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")

def build_schedule(goal, days, hours_per_day):
    tasks = ["Learn/review core concepts", "Practice with active recall", "Solve/application practice", "Review mistakes and weak areas", "Self-test and consolidate"]
    return [{"day": d, "hours": hours_per_day, "focus": tasks[(d-1) % len(tasks)], "goal": goal} for d in range(1, days + 1)]
