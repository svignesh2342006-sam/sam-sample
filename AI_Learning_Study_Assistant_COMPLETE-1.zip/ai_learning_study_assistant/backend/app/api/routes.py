from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from sqlalchemy.orm import selectinload
from app.core.config import settings
from app.db.database import get_db
from app.models.models import Document, Chunk, Memory, Conversation, Message
from app.schemas.schemas import *
from app.services.document_service import extract_text, chunk_pages
from app.services.vector_service import vector_service
from app.services.agent_service import agent_service
from app.services.memory_service import memory_service
from app.services.llm_service import llm_service

router=APIRouter(prefix="/api")

@router.get("/health")
async def health(): return {"status":"ok","service":settings.app_name}

@router.get("/documents")
async def documents(db:AsyncSession=Depends(get_db)):
    rows=(await db.execute(select(Document).order_by(desc(Document.created_at)))).scalars().all()
    return [{"id":d.id,"filename":d.filename,"title":d.title,"file_type":d.file_type,"status":d.status,"created_at":d.created_at} for d in rows]

@router.post("/documents/upload")
async def upload(file:UploadFile=File(...), db:AsyncSession=Depends(get_db)):
    allowed={".pdf",".docx",".txt",".md"}; suffix=Path(file.filename or "").suffix.lower()
    if suffix not in allowed: raise HTTPException(400,"Unsupported file type")
    data=await file.read()
    if len(data)>settings.max_upload_mb*1024*1024: raise HTTPException(413,"File too large")
    safe=f"{uuid4().hex}{suffix}"; path=Path(settings.upload_dir)/safe; path.write_bytes(data)
    doc=Document(filename=file.filename, title=Path(file.filename).stem, file_type=suffix[1:], status="processing"); db.add(doc); await db.commit(); await db.refresh(doc)
    try:
        pages=extract_text(path); chunks=chunk_pages(pages)
        if not chunks: raise ValueError("No readable text found")
        records=[]; ids=[]; texts=[]; metas=[]
        for i,(content,page) in enumerate(chunks):
            c=Chunk(document_id=doc.id,chunk_index=i,content=content,page=page); db.add(c); records.append(c)
            ids.append(f"doc-{doc.id}-chunk-{i}"); texts.append(content); metas.append({"document_id":str(doc.id),"filename":doc.filename,"page":str(page or "N/A"),"chunk_index":str(i)})
        vector_service.add(ids,texts,metas); doc.status="indexed"; await db.commit()
        return {"id":doc.id,"filename":doc.filename,"chunks":len(chunks),"status":doc.status}
    except Exception as e:
        doc.status="error"; await db.commit(); path.unlink(missing_ok=True); raise HTTPException(500,f"Indexing failed: {e}")

@router.delete("/documents/{doc_id}")
async def delete_document(doc_id:int, db:AsyncSession=Depends(get_db)):
    doc=await db.get(Document,doc_id)
    if not doc: raise HTTPException(404,"Document not found")
    vector_service.delete_document(doc_id); await db.delete(doc); await db.commit(); return {"deleted":True}

@router.post("/chat",response_model=ChatResponse)
async def chat(req:ChatRequest, db:AsyncSession=Depends(get_db)):
    conv=await db.get(Conversation,req.conversation_id) if req.conversation_id else None
    if not conv:
        conv=Conversation(title=req.message[:80]); db.add(conv); await db.commit(); await db.refresh(conv)
    db.add(Message(conversation_id=conv.id,role="user",content=req.message)); await db.commit()
    try: answer,intent,sources,tools,memories=await agent_service.run(db,req.message)
    except RuntimeError as e: raise HTTPException(503,str(e))
    db.add(Message(conversation_id=conv.id,role="assistant",content=answer)); await db.commit()
    return ChatResponse(answer=answer,conversation_id=conv.id,intent=intent,sources=sources,tools_used=tools,memories_used=memories)

@router.get("/conversations")
async def conversations(db:AsyncSession=Depends(get_db)):
    rows=(await db.execute(select(Conversation).order_by(desc(Conversation.created_at)))).scalars().all()
    return [{"id":c.id,"title":c.title,"created_at":c.created_at} for c in rows]

@router.get("/conversations/{conversation_id}")
async def conversation(conversation_id:int, db:AsyncSession=Depends(get_db)):
    c=(await db.execute(select(Conversation).options(selectinload(Conversation.messages)).where(Conversation.id==conversation_id))).scalar_one_or_none()
    if not c: raise HTTPException(404,"Conversation not found")
    return {"id":c.id,"title":c.title,"messages":[{"role":m.role,"content":m.content,"created_at":m.created_at} for m in c.messages]}

@router.get("/memories")
async def memories(db:AsyncSession=Depends(get_db)):
    rows=(await db.execute(select(Memory).order_by(desc(Memory.created_at)))).scalars().all()
    return [{"id":m.id,"kind":m.kind,"content":m.content,"importance":m.importance,"created_at":m.created_at} for m in rows]

@router.post("/memories")
async def add_memory(req:MemoryCreate, db:AsyncSession=Depends(get_db)):
    m=await memory_service.add(db,req.content,req.kind,req.importance); return {"id":m.id,"content":m.content}

@router.delete("/memories/{memory_id}")
async def delete_memory(memory_id:int,db:AsyncSession=Depends(get_db)):
    m=await db.get(Memory,memory_id)
    if not m: raise HTTPException(404,"Memory not found")
    await db.delete(m); await db.commit(); return {"deleted":True}

@router.post("/plans")
async def plan(req:PlanRequest, db:AsyncSession=Depends(get_db)):
    msg=f"Create a {req.days}-day study plan for {req.goal}, with {req.hours_per_day} hours per day."
    answer,_,sources,tools,mem=await agent_service.run(db,msg); return {"answer":answer,"sources":sources,"tools_used":tools}

@router.post("/quizzes")
async def quiz(req:QuizRequest, db:AsyncSession=Depends(get_db)):
    q=f"Generate {req.count} MCQs from my course material about {req.topic}. Include 4 options, correct answer, and a one-line explanation."
    answer,_,sources,tools,mem=await agent_service.run(db,q); return {"answer":answer,"sources":sources}

@router.post("/summaries")
async def summary(req:SummaryRequest, db:AsyncSession=Depends(get_db)):
    q=f"Summarize the uploaded course material about {req.topic} into concise revision notes with key terms and important points."
    answer,_,sources,tools,mem=await agent_service.run(db,q); return {"answer":answer,"sources":sources}

@router.post("/tools/calculate")
async def calculate(req:CalculationRequest):
    from app.tools.tools import calculator
    try:return {"result":calculator(req.expression)}
    except Exception as e: raise HTTPException(400,str(e))
