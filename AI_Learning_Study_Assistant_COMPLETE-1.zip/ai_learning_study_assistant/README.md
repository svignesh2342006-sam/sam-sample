# AI Learning & Study Assistant

A complete agentic learning assistant implementing the uploaded project requirements: **RAG + Memory + Tools**. The system ingests course materials, indexes them with embeddings, retrieves relevant chunks before course-specific answers, keeps useful learner context, and uses tools for computations/actions. It also creates study plans, summaries, quizzes, and revision support.

## Architecture

`React UI → FastAPI → Agent → Memory + RAG Retriever + Tools → LLM → Response`

Course documents are stored in `data/uploads`, metadata/memory in SQLite, and the vector index in `data/chroma`.

## Requirements

- Python 3.11+
- Node.js 20+
- An OpenAI-compatible LLM API key **or** a local Ollama model.

## Backend setup

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

If using OpenAI-compatible API, set `LLM_PROVIDER=openai` and `OPENAI_API_KEY`. If using Ollama, set `LLM_PROVIDER=ollama`, `OLLAMA_BASE_URL`, and `OLLAMA_MODEL`.

The backend automatically creates SQLite tables and the vector collection.

## Frontend setup

```bash
cd frontend
npm install
npm run dev
```

Open the displayed Vite URL (normally `http://localhost:5173`).

## Features

- Upload PDF, DOCX, TXT, and Markdown course materials.
- Chunking + local embedding model + persistent Chroma vector store.
- Course-grounded Q&A with retrieved source citations.
- Conversation/learning memory with relevance search and explicit useful-memory capture.
- Agent workflow that classifies requests, retrieves context, chooses tools, then generates a grounded response.
- Tools: calculator, date/time, and study-plan schedule builder.
- Learning-plan generation.
- Quiz generation from course material.
- Summarization and revision notes.
- Conversation history and course library.
- Health/status endpoint and automated backend tests.

## Important configuration

Secrets are never committed. Copy `backend/.env.example` to `backend/.env`.

For a no-cloud setup, install/run Ollama and use an installed chat model. Embeddings run locally through SentenceTransformers.

## Test

```bash
cd backend
pytest -q
```

## API

- `GET /api/health`
- `POST /api/documents/upload`
- `GET /api/documents`
- `DELETE /api/documents/{id}`
- `POST /api/chat`
- `GET /api/conversations`
- `GET /api/memories`
- `POST /api/memories`
- `DELETE /api/memories/{id}`
- `POST /api/plans`
- `POST /api/quizzes`
- `POST /api/summaries`
- `POST /api/tools/calculate`

## Requirement mapping

The uploaded guide explicitly requires personalized plans, course-material RAG, useful memory, tools, explanations/summaries/quizzes/revision plans, and the workflow of input → retrieval → memory → agent/LLM → tools → response. This implementation follows that structure. fileciteturn0file0L12-L34
