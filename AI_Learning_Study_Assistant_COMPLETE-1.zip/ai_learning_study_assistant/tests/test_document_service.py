import sys
sys.path.insert(0,"backend")
from app.services.document_service import chunk_pages

def test_chunking():
    chunks=chunk_pages([("hello "*500,1)],chunk_size=100,overlap=20)
    assert len(chunks)>1
    assert all(x[1]==1 for x in chunks)
