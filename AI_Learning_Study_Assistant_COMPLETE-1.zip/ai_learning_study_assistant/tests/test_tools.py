import sys
sys.path.insert(0,"backend")
from app.tools.tools import calculator, build_schedule

def test_calculator():
    assert calculator("2 + 3 * 4") == "14"

def test_schedule():
    s=build_schedule("ML exam",7,2)
    assert len(s)==7 and s[0]["hours"]==2
